package com.socialmedia.interfaces;

public interface SentimentAnalyzer {
    void analyzeSentiment(String comment);
}