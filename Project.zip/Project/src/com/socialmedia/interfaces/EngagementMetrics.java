package com.socialmedia.interfaces;

public interface EngagementMetrics {
    void trackLikes();
}